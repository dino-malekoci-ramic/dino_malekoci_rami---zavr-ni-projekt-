function changeColor() {
    var w = window.outerWidth;
    var h = window.outerHeight;
    if(w>1280 || h>1024)
        document.getElementById("responsive").style.backgroundColor = "lightskyblue";
    else
        document.getElementById("responsive").style.backgroundColor = "red";
}